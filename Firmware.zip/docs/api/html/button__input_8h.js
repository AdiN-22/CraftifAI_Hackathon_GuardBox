var button__input_8h =
[
    [ "button_press_event_t", "structbutton__press__event__t.html", "structbutton__press__event__t" ],
    [ "button_id_t", "button__input_8h.html#aa4f1ea6f585e6aacce1ff590abd3fb69", [
      [ "BUTTON_INPUT_SW0", "button__input_8h.html#aa4f1ea6f585e6aacce1ff590abd3fb69ad1b65fdc85f9d3d5a2ab7e90c9a4040f", null ],
      [ "BUTTON_INPUT_SW1", "button__input_8h.html#aa4f1ea6f585e6aacce1ff590abd3fb69ae554b7a5f1f20b4d5559505d5f7e9512", null ]
    ] ],
    [ "button_input_start", "button__input_8h.html#a06956ef5ad3f2bf1e1dd67c47d56ad80", null ]
];
var annotated_dup =
[
    [ "button_press_event_t", "structbutton__press__event__t.html", "structbutton__press__event__t" ],
    [ "echo_edge_t", "structecho__edge__t.html", "structecho__edge__t" ],
    [ "hcsr04_sample_t", "structhcsr04__sample__t.html", "structhcsr04__sample__t" ],
    [ "mpu6050_sample_t", "structmpu6050__sample__t.html", "structmpu6050__sample__t" ]
];
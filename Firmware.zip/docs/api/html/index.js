var index =
[
    [ "Purpose", "index.html#autotoc_md1", null ],
    [ "Firmware topology and wiring", "index.html#autotoc_md2", null ],
    [ "State behavior and configuration", "index.html#autotoc_md3", null ],
    [ "Build and verification", "index.html#autotoc_md4", null ]
];
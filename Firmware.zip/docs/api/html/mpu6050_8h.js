var mpu6050_8h =
[
    [ "mpu6050_sample_t", "structmpu6050__sample__t.html", "structmpu6050__sample__t" ],
    [ "mpu6050_get_latest", "mpu6050_8h.html#af259d6bae363bddfe2c46ae701639e74", null ],
    [ "mpu6050_start", "mpu6050_8h.html#a17adc1341f451ff5f5433a64dcb43c4c", null ]
];
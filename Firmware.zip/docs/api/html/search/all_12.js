var searchData=
[
  ['valid_0',['valid',['../structhcsr04__sample__t.html#a18ae30e1af46b0524b22afe1b55c828b',1,'hcsr04_sample_t::valid'],['../structmpu6050__sample__t.html#aafb70eef822434a76bdd7ff290911518',1,'mpu6050_sample_t::valid']]],
  ['verification_1',['Build and verification',['../index.html#autotoc_md4',1,'']]]
];

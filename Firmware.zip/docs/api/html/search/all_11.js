var searchData=
[
  ['unused_0',['UNUSED',['../helpers_8h.html#a86d500a34c624c2cae56bc25a31b12f3',1,'helpers.h']]],
  ['update_5fyellow_5fled_1',['update_yellow_led',['../app_8c.html#a033b18b5d2f816df5ecadb06b3d8a660',1,'app.c']]]
];

var searchData=
[
  ['capture_5fbaselines_0',['capture_baselines',['../app_8c.html#a275bbb2e802ca998e1581b199e07285a',1,'app.c']]],
  ['configure_5foutputs_1',['configure_outputs',['../app_8c.html#abaeda1fca8febd316861cadb85ea37c8',1,'app.c']]],
  ['controller_5ftask_2',['controller_task',['../app_8c.html#a9d9302f089375e91cc6a794a562beae9',1,'app.c']]]
];

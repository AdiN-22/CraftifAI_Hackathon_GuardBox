var searchData=
[
  ['next_5fdiagnostic_0',['next_diagnostic',['../app_8c.html#a5075ee98d703c3594f2915e9c8727e45',1,'app.c']]],
  ['next_5fyellow_5fled_5fchange_1',['next_yellow_led_change',['../app_8c.html#a8fdea39b99634beef777b2c749766f76',1,'app.c']]]
];

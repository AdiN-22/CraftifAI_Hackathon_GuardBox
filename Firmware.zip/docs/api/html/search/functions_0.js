var searchData=
[
  ['app_5fstart_0',['app_start',['../app_8c.html#af0c94d79193624994df85c52e2e30ca4',1,'app_start(void):&#160;app.c'],['../app_8h.html#af0c94d79193624994df85c52e2e30ca4',1,'app_start(void):&#160;app.c']]],
  ['arm_5fsystem_1',['arm_system',['../app_8c.html#a1bd231999387d6a4e30cea229616f66b',1,'app.c']]]
];

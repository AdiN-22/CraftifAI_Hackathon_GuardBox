var searchData=
[
  ['diagnostic_5flog_0',['diagnostic_log',['../app_8c.html#ab840855097f430237b1c954b076235b6',1,'app.c']]],
  ['disarm_5fsystem_1',['disarm_system',['../app_8c.html#aa45b404255eb411bfe77a7e40c0dc430',1,'app.c']]]
];

var searchData=
[
  ['sample_5fmutex_0',['sample_mutex',['../hcsr04_8c.html#a860338d52d0aa23cef058ee503685a24',1,'sample_mutex:&#160;hcsr04.c'],['../mpu6050_8c.html#a860338d52d0aa23cef058ee503685a24',1,'sample_mutex:&#160;mpu6050.c']]],
  ['sample_5ftask_1',['sample_task',['../mpu6050_8c.html#a2d281faa7cff5c9b3a1594d4753865d4',1,'mpu6050.c']]],
  ['set_5foutputs_2',['set_outputs',['../app_8c.html#a952f398159a3d68344f28c8e493cf6da',1,'app.c']]],
  ['source_20layout_3',['Source layout',['../dir_d9edf6c004b4a7ff14fe9ae7a92214ee.html#autotoc_md7',1,'']]],
  ['started_4',['started',['../hcsr04_8c.html#a43c08d193d555a2b2a61c53d2a4e5a63',1,'started:&#160;hcsr04.c'],['../mpu6050_8c.html#a43c08d193d555a2b2a61c53d2a4e5a63',1,'started:&#160;mpu6050.c']]],
  ['state_20behavior_20and_20configuration_5',['State behavior and configuration',['../index.html#autotoc_md3',1,'']]]
];

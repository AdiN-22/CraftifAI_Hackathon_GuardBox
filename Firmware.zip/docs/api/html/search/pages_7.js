var searchData=
[
  ['project_0',['CrafitifiAI GuardBox Project',['../dir_d9edf6c004b4a7ff14fe9ae7a92214ee.html#autotoc_md5',1,'']]],
  ['purpose_1',['Purpose',['../index.html#autotoc_md1',1,'']]]
];

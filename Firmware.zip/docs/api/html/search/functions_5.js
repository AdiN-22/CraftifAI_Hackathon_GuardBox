var searchData=
[
  ['fresh_0',['fresh',['../app_8c.html#a54157ca89df7477aa0772c01bde3e355',1,'app.c']]]
];

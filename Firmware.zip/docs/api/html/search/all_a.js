var searchData=
[
  ['max_0',['MAX',['../helpers_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'helpers.h']]],
  ['measure_5ftask_1',['measure_task',['../hcsr04_8c.html#aaf2dd002c1175108816ad99081634e87',1,'hcsr04.c']]],
  ['min_2',['MIN',['../helpers_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'helpers.h']]],
  ['monitor_3',['CrafitifiAI GuardBox Armed Tamper Monitor',['../index.html',1,'']]],
  ['mpu6050_2ec_4',['mpu6050.c',['../mpu6050_8c.html',1,'']]],
  ['mpu6050_2eh_5',['mpu6050.h',['../mpu6050_8h.html',1,'']]],
  ['mpu6050_5fget_5flatest_6',['mpu6050_get_latest',['../mpu6050_8c.html#af259d6bae363bddfe2c46ae701639e74',1,'mpu6050_get_latest(mpu6050_sample_t *sample):&#160;mpu6050.c'],['../mpu6050_8h.html#af259d6bae363bddfe2c46ae701639e74',1,'mpu6050_get_latest(mpu6050_sample_t *sample):&#160;mpu6050.c']]],
  ['mpu6050_5freg_5faccel_5fconfig_7',['MPU6050_REG_ACCEL_CONFIG',['../mpu6050_8c.html#a35e7929d2f47c186b37c0c14f7e2f748',1,'mpu6050.c']]],
  ['mpu6050_5freg_5faccel_5fxout_5fh_8',['MPU6050_REG_ACCEL_XOUT_H',['../mpu6050_8c.html#a261db4cdf256b4353a24192e98b9844e',1,'mpu6050.c']]],
  ['mpu6050_5freg_5fconfig_9',['MPU6050_REG_CONFIG',['../mpu6050_8c.html#a29b84c38e3819ab3ef2194f87acc0265',1,'mpu6050.c']]],
  ['mpu6050_5freg_5fgyro_5fconfig_10',['MPU6050_REG_GYRO_CONFIG',['../mpu6050_8c.html#aa6047e49a54fa8813bd415c98a889455',1,'mpu6050.c']]],
  ['mpu6050_5freg_5fpwr_5fmgmt_5f1_11',['MPU6050_REG_PWR_MGMT_1',['../mpu6050_8c.html#aeeaa101e6be02c7e3c7b74a08c3f0ab2',1,'mpu6050.c']]],
  ['mpu6050_5freg_5fsmplrt_5fdiv_12',['MPU6050_REG_SMPLRT_DIV',['../mpu6050_8c.html#a7295cab687a78a749c9304953af72bbe',1,'mpu6050.c']]],
  ['mpu6050_5freg_5fwho_5fam_5fi_13',['MPU6050_REG_WHO_AM_I',['../mpu6050_8c.html#a1a7574ee53e6dc1754c8d7ddb64d2faf',1,'mpu6050.c']]],
  ['mpu6050_5fsample_5ft_14',['mpu6050_sample_t',['../structmpu6050__sample__t.html',1,'']]],
  ['mpu6050_5fstart_15',['mpu6050_start',['../mpu6050_8c.html#a17adc1341f451ff5f5433a64dcb43c4c',1,'mpu6050_start(void):&#160;mpu6050.c'],['../mpu6050_8h.html#a17adc1341f451ff5f5433a64dcb43c4c',1,'mpu6050_start(void):&#160;mpu6050.c']]],
  ['mpu6050_5fwho_5fam_5fi_5fvalue_16',['MPU6050_WHO_AM_I_VALUE',['../mpu6050_8c.html#a07dcdc4b0a23df891ee846a659d2fd58',1,'mpu6050.c']]]
];

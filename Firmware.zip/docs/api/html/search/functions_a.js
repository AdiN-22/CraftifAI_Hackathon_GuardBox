var searchData=
[
  ['sample_5ftask_0',['sample_task',['../mpu6050_8c.html#a2d281faa7cff5c9b3a1594d4753865d4',1,'mpu6050.c']]],
  ['set_5foutputs_1',['set_outputs',['../app_8c.html#a952f398159a3d68344f28c8e493cf6da',1,'app.c']]]
];

var searchData=
[
  ['imu_5fbaseline_0',['imu_baseline',['../app_8c.html#aa892937cd523d6b99b3b6adc11599fbc',1,'app.c']]],
  ['imu_5fbaseline_5fvalid_1',['imu_baseline_valid',['../app_8c.html#af125b578349d5a508982c8c7df540b47',1,'app.c']]]
];

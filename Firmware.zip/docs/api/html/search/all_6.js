var searchData=
[
  ['guardbox_20armed_20tamper_20monitor_0',['CrafitifiAI GuardBox Armed Tamper Monitor',['../index.html',1,'']]],
  ['guardbox_20project_1',['CrafitifiAI GuardBox Project',['../dir_d9edf6c004b4a7ff14fe9ae7a92214ee.html#autotoc_md5',1,'']]],
  ['gx_5fdps_2',['gx_dps',['../structmpu6050__sample__t.html#a8bf9c28d0b1f70f227d439dcf08c1e72',1,'mpu6050_sample_t']]],
  ['gy_5fdps_3',['gy_dps',['../structmpu6050__sample__t.html#a9507f92f7a5ef2e0866af1a40c3e2f2f',1,'mpu6050_sample_t']]],
  ['gz_5fdps_4',['gz_dps',['../structmpu6050__sample__t.html#a55e67c185d730f45408556cbb3d3f215',1,'mpu6050_sample_t']]]
];

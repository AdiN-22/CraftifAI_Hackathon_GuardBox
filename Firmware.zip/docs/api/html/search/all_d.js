var searchData=
[
  ['platform_5fconfig_2eh_0',['platform_config.h',['../platform__config_8h.html',1,'']]],
  ['press_5fqueue_1',['press_queue',['../button__input_8c.html#aa7235309e89da1055daf8df6aa9cdc72',1,'button_input.c']]],
  ['project_2',['CrafitifiAI GuardBox Project',['../dir_d9edf6c004b4a7ff14fe9ae7a92214ee.html#autotoc_md5',1,'']]],
  ['publish_5farmed_3',['publish_armed',['../app_8c.html#aa528a97e1897f39c77747c14ae4c613d',1,'app.c']]],
  ['publish_5fdisarmed_4',['publish_disarmed',['../app_8c.html#a807ec73fe64fafe50c9c7354988cfb5e',1,'app.c']]],
  ['purpose_5',['Purpose',['../index.html#autotoc_md1',1,'']]]
];

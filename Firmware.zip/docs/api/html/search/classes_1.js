var searchData=
[
  ['echo_5fedge_5ft_0',['echo_edge_t',['../structecho__edge__t.html',1,'']]]
];

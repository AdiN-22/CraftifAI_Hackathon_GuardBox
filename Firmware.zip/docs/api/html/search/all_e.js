var searchData=
[
  ['readme_2emd_0',['README.md',['../README_8md.html',1,'']]],
  ['register_5fread_1',['register_read',['../mpu6050_8c.html#a7ffcf0c597d5dbb21ba0429c6f9b90fe',1,'mpu6050.c']]],
  ['register_5fwrite_2',['register_write',['../mpu6050_8c.html#ab12fdaca4d531348e20ee957198f3692',1,'mpu6050.c']]]
];

var searchData=
[
  ['firmware_20topology_20and_20wiring_0',['Firmware topology and wiring',['../index.html#autotoc_md2',1,'']]],
  ['fresh_1',['fresh',['../app_8c.html#a54157ca89df7477aa0772c01bde3e355',1,'app.c']]]
];

var structhcsr04__sample__t =
[
    [ "distance_cm", "structhcsr04__sample__t.html#a6303c25d8f9ce13938dba7301e2f4881", null ],
    [ "timestamp_us", "structhcsr04__sample__t.html#a823b5f3e77537aeb95a2080a6cea5426", null ],
    [ "valid", "structhcsr04__sample__t.html#a18ae30e1af46b0524b22afe1b55c828b", null ]
];
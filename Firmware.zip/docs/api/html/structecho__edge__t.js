var structecho__edge__t =
[
    [ "level", "structecho__edge__t.html#a0a3521e8f5623545b566370c3535ca5d", null ],
    [ "timestamp_us", "structecho__edge__t.html#a8d13fe23a41537a8355131fa42ff0c8a", null ]
];
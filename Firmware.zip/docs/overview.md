# CrafitifiAI GuardBox Armed Tamper Monitor

## Purpose

This ESP-IDF firmware controls green, blue, red, and yellow LEDs, two debounced buttons, an MPU-6050, and an HC-SR04 distance sensor. SW0 arms or disarms the GuardBox. While armed, fresh sensor readings are compared with baselines captured at arming. Motion, tilt, gyro activity, or lid-gap distance changes can enter a latched ALERT state. SW1 acknowledges ALERT by turning off the pulsed yellow LED while leaving the red LED on.

## Firmware topology and wiring

- SW0: GPIO4 to GND; active-low input with internal pull-up
- SW1: GPIO13 to GND; active-low input with internal pull-up
- Green LED: GPIO25, active-high
- Blue LED: GPIO26, active-high
- Red LED: GPIO27, active-high
- Yellow alert LED: GPIO32, active-high
- MPU-6050 SDA: GPIO21; SCL: GPIO22; address 0x68
- HC-SR04 TRIG: GPIO5; ECHO: GPIO18 through a 5 V-to-3.3 V divider or level shifter

Sensor modules publish thread-safe latest samples to the application controller. The controller owns armed, alert, acknowledgement, baselines, and LED state. Sensor tasks remain independent and use bounded operations so missing sensors do not block button handling or other monitoring.

## State behavior and configuration

On startup, all LEDs blink once and the system settles disarmed with green on and yellow off. SW0 captures fresh sensor baselines and selects blue while armed. Default alert thresholds are 0.20 g acceleration delta, 15 degrees tilt, 50 dps gyro magnitude, and 5 cm distance change. ALERT selects the red LED and pulses the yellow LED at 250 ms intervals. SW1 silences the yellow LED; SW0 clears ALERT and returns to green. Disarmed diagnostics are logged every 5 seconds without alert evaluation.

All GPIO assignments, thresholds, timing, debounce values, and freshness limits are centralized in `firmware/configs/app_config.h`. The firmware is configured for the ESP32 target with 4 MB flash.

## Build and verification

Build and flash with the ESP-IDF tools. The serial console uses 115200 baud. Logs report state transitions, baseline availability, sensor availability, alert sources, acknowledgement, and bounded sensor failures. Physical button presses and sensor-triggered transitions require confirmation with the connected hardware.

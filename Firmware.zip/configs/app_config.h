#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* Output GPIO assignments. All selected pins are safe for this ESP32 board. */
#define APP_GREEN_LED_GPIO 25
#define APP_BLUE_LED_GPIO 26
#define APP_RED_LED_GPIO 27
#define APP_YELLOW_LED_GPIO 32

/* Active levels for the connected outputs. */
#define APP_LED_ACTIVE_LEVEL 1
#define APP_YELLOW_LED_ACTIVE_LEVEL 1

/* Startup confirmation blink timing. */
#define APP_STARTUP_BLINK_ON_MS 250
#define APP_STARTUP_BLINK_OFF_MS 250

/* Active-low momentary switch inputs. COM is tied to GND. */
#define APP_SW0_GPIO 4
#define APP_SW1_GPIO 13
#define APP_BUTTON_POLL_MS 10
#define APP_BUTTON_DEBOUNCE_MS 30
#define APP_BUTTON_EVENT_QUEUE_LENGTH 8
#define APP_BUTTON_TASK_STACK_SIZE 2048
#define APP_BUTTON_TASK_PRIORITY 5

/* MPU-6050 I2C configuration and sampling. */
#define APP_IMU_SDA_GPIO 21
#define APP_IMU_SCL_GPIO 22
#define APP_IMU_I2C_PORT 0
#define APP_IMU_I2C_ADDRESS 0x68
#define APP_IMU_I2C_FREQ_HZ 400000
#define APP_IMU_I2C_TIMEOUT_MS 100
#define APP_IMU_SAMPLE_PERIOD_MS 100
#define APP_IMU_TASK_STACK_SIZE 3072
#define APP_IMU_TASK_PRIORITY 4
#define APP_IMU_ACCEL_SCALE_G 16384.0f
#define APP_IMU_GYRO_SCALE_DPS 131.0f

/* HC-SR04 ultrasonic distance sensor. ECHO must be level-shifted to 3.3 V. */
#define APP_HCSR04_TRIG_GPIO 5
#define APP_HCSR04_ECHO_GPIO 18
#define APP_HCSR04_MEASURE_PERIOD_MS 500
#define APP_HCSR04_TRIGGER_PULSE_US 10
#define APP_HCSR04_ECHO_TIMEOUT_US 30000
#define APP_HCSR04_EVENT_QUEUE_LENGTH 8
#define APP_HCSR04_TASK_STACK_SIZE 3072
#define APP_HCSR04_TASK_PRIORITY 4
#define APP_HCSR04_CM_PER_US 0.01715f

/* Yellow alert LED uses the former buzzer GPIO. */
#define APP_YELLOW_LED_GPIO 32
#define APP_YELLOW_LED_ACTIVE_LEVEL 1

/* Armed-state tamper detection and diagnostics. */
#define APP_CONTROLLER_PERIOD_MS 20
#define APP_IMU_MAX_SAMPLE_AGE_MS 500
#define APP_DISTANCE_MAX_SAMPLE_AGE_MS 1500
#define APP_IMU_ACCEL_DELTA_THRESHOLD_G 0.20f
#define APP_IMU_TILT_THRESHOLD_DEG 15.0f
#define APP_IMU_GYRO_THRESHOLD_DPS 50.0f
#define APP_DISTANCE_DELTA_THRESHOLD_CM 5.0f
#define APP_YELLOW_LED_PULSE_ON_MS 250
#define APP_YELLOW_LED_PULSE_OFF_MS 250
#define APP_DISARMED_DIAGNOSTIC_INTERVAL_MS 5000

#endif /* APP_CONFIG_H */

#include "app.h"
#include "app_config.h"
#include "button_input.h"
#include "mpu6050.h"
#include "hcsr04.h"
#include "logger.h"

#include "driver/gpio.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include <math.h>

static const char *TAG = "guardbox";
static bool armed;
static bool alert;
static bool acknowledged;
static bool imu_baseline_valid;
static bool distance_baseline_valid;
static mpu6050_sample_t imu_baseline;
static hcsr04_sample_t distance_baseline;
static TickType_t next_yellow_led_change;
static bool yellow_led_on;
static TickType_t next_diagnostic;

static esp_err_t configure_outputs(void)
{
    gpio_config_t config = {.pin_bit_mask = (1ULL << APP_GREEN_LED_GPIO) | (1ULL << APP_BLUE_LED_GPIO) |
                            (1ULL << APP_RED_LED_GPIO) | (1ULL << APP_YELLOW_LED_GPIO),
                            .mode = GPIO_MODE_OUTPUT, .pull_up_en = GPIO_PULLUP_DISABLE,
                            .pull_down_en = GPIO_PULLDOWN_DISABLE, .intr_type = GPIO_INTR_DISABLE};
    esp_err_t err = gpio_config(&config);
    if (err != ESP_OK) { ESP_LOGE(TAG, "Output GPIO configuration failed: %s", esp_err_to_name(err)); return err; }
    gpio_set_level(APP_GREEN_LED_GPIO, !APP_LED_ACTIVE_LEVEL);
    gpio_set_level(APP_BLUE_LED_GPIO, !APP_LED_ACTIVE_LEVEL);
    gpio_set_level(APP_RED_LED_GPIO, !APP_LED_ACTIVE_LEVEL);
    gpio_set_level(APP_YELLOW_LED_GPIO, !APP_YELLOW_LED_ACTIVE_LEVEL);
    ESP_LOGI(TAG, "Outputs initialized: green GPIO%d, blue GPIO%d, red GPIO%d, yellow_led GPIO%d",
             APP_GREEN_LED_GPIO, APP_BLUE_LED_GPIO, APP_RED_LED_GPIO, APP_YELLOW_LED_GPIO);
    return ESP_OK;
}

static void set_outputs(bool green, bool blue, bool red, bool yellow_led)
{
    gpio_set_level(APP_GREEN_LED_GPIO, green ? APP_LED_ACTIVE_LEVEL : !APP_LED_ACTIVE_LEVEL);
    gpio_set_level(APP_BLUE_LED_GPIO, blue ? APP_LED_ACTIVE_LEVEL : !APP_LED_ACTIVE_LEVEL);
    gpio_set_level(APP_RED_LED_GPIO, red ? APP_LED_ACTIVE_LEVEL : !APP_LED_ACTIVE_LEVEL);
    gpio_set_level(APP_YELLOW_LED_GPIO, yellow_led ? APP_YELLOW_LED_ACTIVE_LEVEL : !APP_YELLOW_LED_ACTIVE_LEVEL);
}

static bool fresh(int64_t timestamp_us, int max_age_ms)
{
    return timestamp_us > 0 && (esp_timer_get_time() - timestamp_us) <= ((int64_t)max_age_ms * 1000);
}

static void publish_disarmed(void)
{
    set_outputs(true, false, false, false);
    ESP_LOGI(TAG, "STATE DISARMED: green ON, blue/red OFF, yellow_led OFF");
}

static void publish_armed(void)
{
    set_outputs(false, true, false, false);
    ESP_LOGI(TAG, "STATE ARMED: blue ON, alert cleared");
}

static void enter_alert(bool imu_trigger, bool distance_trigger)
{
    alert = true;
    acknowledged = false;
    yellow_led_on = true;
    next_yellow_led_change = xTaskGetTickCount() + pdMS_TO_TICKS(APP_YELLOW_LED_PULSE_ON_MS);
    set_outputs(false, false, true, true);
    ESP_LOGW(TAG, "STATE ALERT: trigger=%s%s%s",
             imu_trigger ? "IMU" : "", (imu_trigger && distance_trigger) ? "+" : "",
             distance_trigger ? "DISTANCE" : "");
}

static void update_yellow_led(void)
{
    if (!alert || acknowledged) return;
    TickType_t now = xTaskGetTickCount();
    if ((int32_t)(now - next_yellow_led_change) >= 0) {
        yellow_led_on = !yellow_led_on;
        gpio_set_level(APP_YELLOW_LED_GPIO, yellow_led_on ? APP_YELLOW_LED_ACTIVE_LEVEL : !APP_YELLOW_LED_ACTIVE_LEVEL);
        next_yellow_led_change = now + pdMS_TO_TICKS(yellow_led_on ? APP_YELLOW_LED_PULSE_ON_MS : APP_YELLOW_LED_PULSE_OFF_MS);
    }
}

static void capture_baselines(void)
{
    imu_baseline_valid = mpu6050_get_latest(&imu_baseline) && fresh(imu_baseline.timestamp_us, APP_IMU_MAX_SAMPLE_AGE_MS);
    distance_baseline_valid = hcsr04_get_latest(&distance_baseline) && fresh(distance_baseline.timestamp_us, APP_DISTANCE_MAX_SAMPLE_AGE_MS);
    ESP_LOGI(TAG, "ARM baseline: IMU=%s%s, DISTANCE=%s%s",
             imu_baseline_valid ? "captured" : "unavailable", imu_baseline_valid ? "" : " (comparison disabled)",
             distance_baseline_valid ? "captured" : "unavailable", distance_baseline_valid ? "" : " (comparison disabled)");
}

static void arm_system(void)
{
    armed = true; alert = false; acknowledged = false; capture_baselines(); publish_armed();
}

static void disarm_system(void)
{
    armed = false; alert = false; acknowledged = false; yellow_led_on = false;
    imu_baseline_valid = false; distance_baseline_valid = false; publish_disarmed();
}

static void evaluate_sensors(void)
{
    if (!armed || alert) return;
    mpu6050_sample_t imu;
    hcsr04_sample_t distance;
    bool imu_trigger = false, distance_trigger = false;
    if (imu_baseline_valid && mpu6050_get_latest(&imu) && fresh(imu.timestamp_us, APP_IMU_MAX_SAMPLE_AGE_MS)) {
        float delta = sqrtf((imu.ax_g - imu_baseline.ax_g) * (imu.ax_g - imu_baseline.ax_g) +
                            (imu.ay_g - imu_baseline.ay_g) * (imu.ay_g - imu_baseline.ay_g) +
                            (imu.az_g - imu_baseline.az_g) * (imu.az_g - imu_baseline.az_g));
        float gyro = sqrtf(imu.gx_dps * imu.gx_dps + imu.gy_dps * imu.gy_dps + imu.gz_dps * imu.gz_dps);
        float dot = imu.ax_g * imu_baseline.ax_g + imu.ay_g * imu_baseline.ay_g + imu.az_g * imu_baseline.az_g;
        float norms = sqrtf((imu.ax_g * imu.ax_g + imu.ay_g * imu.ay_g + imu.az_g * imu.az_g) *
                            (imu_baseline.ax_g * imu_baseline.ax_g + imu_baseline.ay_g * imu_baseline.ay_g + imu_baseline.az_g * imu_baseline.az_g));
        float tilt = (norms > 0.01f) ? acosf(fmaxf(-1.0f, fminf(1.0f, dot / norms))) * 57.29578f : 0.0f;
        imu_trigger = delta >= APP_IMU_ACCEL_DELTA_THRESHOLD_G || tilt >= APP_IMU_TILT_THRESHOLD_DEG || gyro >= APP_IMU_GYRO_THRESHOLD_DPS;
    }
    if (distance_baseline_valid && hcsr04_get_latest(&distance) && fresh(distance.timestamp_us, APP_DISTANCE_MAX_SAMPLE_AGE_MS)) {
        distance_trigger = fabsf(distance.distance_cm - distance_baseline.distance_cm) >= APP_DISTANCE_DELTA_THRESHOLD_CM;
    }
    if (imu_trigger || distance_trigger) enter_alert(imu_trigger, distance_trigger);
}

static void diagnostic_log(void)
{
    mpu6050_sample_t imu; hcsr04_sample_t distance;
    bool have_imu = mpu6050_get_latest(&imu); bool have_distance = hcsr04_get_latest(&distance);
    ESP_LOGI(TAG, "DIAG IMU=%s distance=%s", have_imu ? "valid" : "unavailable", have_distance ? "valid" : "unavailable");
}

static void controller_task(void *arg)
{
    QueueHandle_t events = (QueueHandle_t)arg;
    button_press_event_t event;
    for (;;) {
        if (xQueueReceive(events, &event, pdMS_TO_TICKS(APP_CONTROLLER_PERIOD_MS)) == pdTRUE) {
            if (event.button == BUTTON_INPUT_SW0) {
                if (armed) disarm_system(); else arm_system();
            } else if (event.button == BUTTON_INPUT_SW1) {
                if (alert && !acknowledged) {
                    acknowledged = true; yellow_led_on = false;
                    gpio_set_level(APP_YELLOW_LED_GPIO, !APP_YELLOW_LED_ACTIVE_LEVEL);
                    ESP_LOGI(TAG, "ALERT acknowledged: yellow_led silenced, red LED remains ON");
                } else {
                    ESP_LOGI(TAG, "SW1 press detected; no action in current state");
                }
            }
        }
        evaluate_sensors();
        update_yellow_led();
        if (!armed && (int32_t)(xTaskGetTickCount() - next_diagnostic) >= 0) {
            diagnostic_log(); next_diagnostic = xTaskGetTickCount() + pdMS_TO_TICKS(APP_DISARMED_DIAGNOSTIC_INTERVAL_MS);
        }
    }
}

void app_start(void)
{
    QueueHandle_t button_events = NULL;
    armed = false; alert = false; acknowledged = false;
    ESP_LOGI(TAG, "Initializing GuardBox controller");
    if (configure_outputs() != ESP_OK) return;
    set_outputs(true, true, true, false); vTaskDelay(pdMS_TO_TICKS(APP_STARTUP_BLINK_ON_MS));
    set_outputs(false, false, false, false); vTaskDelay(pdMS_TO_TICKS(APP_STARTUP_BLINK_OFF_MS));
    publish_disarmed();
    if (!button_input_start(&button_events)) { ESP_LOGE(TAG, "Button input initialization failed"); return; }
    if (!mpu6050_start()) ESP_LOGE(TAG, "MPU-6050 unavailable; continuing without IMU comparison");
    if (!hcsr04_start()) ESP_LOGE(TAG, "HC-SR04 unavailable; continuing without distance comparison");
    next_diagnostic = xTaskGetTickCount();
    if (xTaskCreate(controller_task, "guard_controller", 4096, button_events, 6, NULL) != pdPASS) {
        ESP_LOGE(TAG, "GuardBox controller task creation failed"); return;
    }
    ESP_LOGI(TAG, "GuardBox ready: SW0 arms/disarms; SW1 acknowledges ALERT");
}

#ifndef HCSR04_H
#define HCSR04_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    float distance_cm;
    int64_t timestamp_us;
    bool valid;
} hcsr04_sample_t;

/** Initialize the HC-SR04 and start bounded periodic measurements. */
bool hcsr04_start(void);

/** Copy the latest distance sample. Returns false until a valid reading exists. */
bool hcsr04_get_latest(hcsr04_sample_t *sample);

#endif /* HCSR04_H */

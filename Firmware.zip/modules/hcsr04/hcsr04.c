#include "hcsr04.h"
#include "app_config.h"
#include "logger.h"

#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_rom_sys.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

static const char *TAG = "hcsr04";
typedef struct { int level; int64_t timestamp_us; } echo_edge_t;
static QueueHandle_t echo_queue;
static SemaphoreHandle_t sample_mutex;
static hcsr04_sample_t latest;
static bool started;
static bool last_measurement_ok;

static void IRAM_ATTR echo_isr(void *arg)
{
    (void)arg;
    echo_edge_t edge = {gpio_get_level(APP_HCSR04_ECHO_GPIO), esp_timer_get_time()};
    BaseType_t woken = pdFALSE;
    xQueueSendFromISR(echo_queue, &edge, &woken);
    if (woken == pdTRUE) portYIELD_FROM_ISR();
}

static bool wait_for_edge(int expected, echo_edge_t *edge)
{
    int64_t deadline = esp_timer_get_time() + APP_HCSR04_ECHO_TIMEOUT_US;
    while (esp_timer_get_time() < deadline) {
        int64_t remaining = deadline - esp_timer_get_time();
        TickType_t ticks = pdMS_TO_TICKS((remaining + 999) / 1000);
        if (ticks == 0) ticks = 1;
        if (xQueueReceive(echo_queue, edge, ticks) == pdTRUE && edge->level == expected) return true;
    }
    return false;
}

static void measure_task(void *arg)
{
    (void)arg;
    for (;;) {
        xQueueReset(echo_queue);
        gpio_set_level(APP_HCSR04_TRIG_GPIO, 1);
        esp_rom_delay_us(APP_HCSR04_TRIGGER_PULSE_US);
        gpio_set_level(APP_HCSR04_TRIG_GPIO, 0);
        echo_edge_t rise, fall;
        bool ok = wait_for_edge(1, &rise) && wait_for_edge(0, &fall);
        if (ok) {
            int64_t pulse = fall.timestamp_us - rise.timestamp_us;
            if (pulse > 0 && pulse <= APP_HCSR04_ECHO_TIMEOUT_US) {
                hcsr04_sample_t sample = {
                    .distance_cm = pulse * APP_HCSR04_CM_PER_US,
                    .timestamp_us = fall.timestamp_us,
                    .valid = true,
                };
                if (xSemaphoreTake(sample_mutex, pdMS_TO_TICKS(5)) == pdTRUE) {
                    latest = sample;
                    xSemaphoreGive(sample_mutex);
                }
                if (!last_measurement_ok) ESP_LOGI(TAG, "HC-SR04 readings available");
                last_measurement_ok = true;
            } else {
                ok = false;
            }
        }
        if (!ok) {
            if (last_measurement_ok) ESP_LOGW(TAG, "HC-SR04 echo unavailable or timed out");
            last_measurement_ok = false;
        }
        vTaskDelay(pdMS_TO_TICKS(APP_HCSR04_MEASURE_PERIOD_MS));
    }
}

bool hcsr04_get_latest(hcsr04_sample_t *sample)
{
    if (sample == NULL || sample_mutex == NULL ||
        xSemaphoreTake(sample_mutex, pdMS_TO_TICKS(5)) != pdTRUE) return false;
    *sample = latest;
    xSemaphoreGive(sample_mutex);
    return sample->valid;
}

bool hcsr04_start(void)
{
    if (started) return true;
    gpio_config_t trig = {.pin_bit_mask = 1ULL << APP_HCSR04_TRIG_GPIO, .mode = GPIO_MODE_OUTPUT,
                          .pull_up_en = GPIO_PULLUP_DISABLE, .pull_down_en = GPIO_PULLDOWN_DISABLE,
                          .intr_type = GPIO_INTR_DISABLE};
    esp_err_t err = gpio_config(&trig);
    if (err != ESP_OK || gpio_set_level(APP_HCSR04_TRIG_GPIO, 0) != ESP_OK) {
        ESP_LOGE(TAG, "TRIG configuration failed: %s", esp_err_to_name(err)); return false;
    }
    gpio_config_t echo = {.pin_bit_mask = 1ULL << APP_HCSR04_ECHO_GPIO, .mode = GPIO_MODE_INPUT,
                          .pull_up_en = GPIO_PULLUP_DISABLE, .pull_down_en = GPIO_PULLDOWN_DISABLE,
                          .intr_type = GPIO_INTR_ANYEDGE};
    err = gpio_config(&echo);
    if (err != ESP_OK) { ESP_LOGE(TAG, "ECHO configuration failed: %s", esp_err_to_name(err)); return false; }
    echo_queue = xQueueCreate(APP_HCSR04_EVENT_QUEUE_LENGTH, sizeof(echo_edge_t));
    sample_mutex = xSemaphoreCreateMutex();
    if (echo_queue == NULL || sample_mutex == NULL) { ESP_LOGE(TAG, "HC-SR04 synchronization creation failed"); return false; }
    err = gpio_install_isr_service(0);
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) { ESP_LOGE(TAG, "ISR service failed: %s", esp_err_to_name(err)); return false; }
    err = gpio_isr_handler_add(APP_HCSR04_ECHO_GPIO, echo_isr, NULL);
    if (err != ESP_OK) { ESP_LOGE(TAG, "ECHO ISR registration failed: %s", esp_err_to_name(err)); return false; }
    if (xTaskCreate(measure_task, "hcsr04_measure", APP_HCSR04_TASK_STACK_SIZE, NULL,
                    APP_HCSR04_TASK_PRIORITY, NULL) != pdPASS) { ESP_LOGE(TAG, "HC-SR04 task creation failed"); return false; }
    started = true;
    last_measurement_ok = false;
    ESP_LOGI(TAG, "HC-SR04 initialized: TRIG GPIO%d, ECHO GPIO%d, period %d ms",
             APP_HCSR04_TRIG_GPIO, APP_HCSR04_ECHO_GPIO, APP_HCSR04_MEASURE_PERIOD_MS);
    return true;
}

#include "button_input.h"
#include "app_config.h"
#include "logger.h"

#include "driver/gpio.h"
#include "freertos/task.h"

static const char *TAG = "button_input";

static const gpio_num_t button_gpios[] = {
    APP_SW0_GPIO,
    APP_SW1_GPIO,
};

static QueueHandle_t press_queue;

static void button_task(void *arg)
{
    (void)arg;
    int stable_level[2] = {1, 1};
    int candidate_level[2] = {1, 1};
    TickType_t candidate_since[2] = {0, 0};

    for (;;) {
        TickType_t now = xTaskGetTickCount();
        for (size_t i = 0; i < 2; ++i) {
            int level = gpio_get_level(button_gpios[i]);
            if (level != candidate_level[i]) {
                candidate_level[i] = level;
                candidate_since[i] = now;
            } else if (level != stable_level[i] &&
                       (now - candidate_since[i]) >= pdMS_TO_TICKS(APP_BUTTON_DEBOUNCE_MS)) {
                int previous_level = stable_level[i];
                stable_level[i] = level;
                if (previous_level == 1 && level == 0) {
                    button_press_event_t event = {.button = (button_id_t)i};
                    if (xQueueSend(press_queue, &event, 0) != pdTRUE) {
                        ESP_LOGW(TAG, "Press event queue full; dropped SW%u event", (unsigned)i);
                    }
                }
            }
        }
        vTaskDelay(pdMS_TO_TICKS(APP_BUTTON_POLL_MS));
    }
}

bool button_input_start(QueueHandle_t *event_queue)
{
    if (event_queue == NULL || press_queue != NULL) {
        return false;
    }

    gpio_config_t config = {
        .pin_bit_mask = (1ULL << APP_SW0_GPIO) | (1ULL << APP_SW1_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    esp_err_t err = gpio_config(&config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Button GPIO configuration failed: %s", esp_err_to_name(err));
        return false;
    }

    press_queue = xQueueCreate(APP_BUTTON_EVENT_QUEUE_LENGTH, sizeof(button_press_event_t));
    if (press_queue == NULL) {
        ESP_LOGE(TAG, "Failed to create button press event queue");
        return false;
    }

    if (xTaskCreate(button_task, "button_input", APP_BUTTON_TASK_STACK_SIZE,
                    NULL, APP_BUTTON_TASK_PRIORITY, NULL) != pdPASS) {
        vQueueDelete(press_queue);
        press_queue = NULL;
        ESP_LOGE(TAG, "Failed to create button input task");
        return false;
    }

    *event_queue = press_queue;
    ESP_LOGI(TAG, "SW0 GPIO%d and SW1 GPIO%d initialized as active-low inputs with pull-ups",
             APP_SW0_GPIO, APP_SW1_GPIO);
    ESP_LOGI(TAG, "Debouncing every %d ms; press events require HIGH-to-LOW transition",
             APP_BUTTON_DEBOUNCE_MS);
    return true;
}

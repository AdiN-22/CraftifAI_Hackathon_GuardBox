#ifndef BUTTON_INPUT_H
#define BUTTON_INPUT_H

#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

typedef enum {
    BUTTON_INPUT_SW0 = 0,
    BUTTON_INPUT_SW1,
} button_id_t;

typedef struct {
    button_id_t button;
} button_press_event_t;

/** Start debounced active-low switch monitoring and return its press-event queue. */
bool button_input_start(QueueHandle_t *event_queue);

#endif /* BUTTON_INPUT_H */

#include "mpu6050.h"
#include "app_config.h"
#include "logger.h"

#include "driver/i2c_master.h"
#include "esp_err.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include <math.h>
#include <stdint.h>

static const char *TAG = "mpu6050";
#define MPU6050_REG_SMPLRT_DIV 0x19
#define MPU6050_REG_CONFIG 0x1A
#define MPU6050_REG_GYRO_CONFIG 0x1B
#define MPU6050_REG_ACCEL_CONFIG 0x1C
#define MPU6050_REG_ACCEL_XOUT_H 0x3B
#define MPU6050_REG_PWR_MGMT_1 0x6B
#define MPU6050_REG_WHO_AM_I 0x75
#define MPU6050_WHO_AM_I_VALUE 0x68

static i2c_master_bus_handle_t bus_handle;
static i2c_master_dev_handle_t dev_handle;
static SemaphoreHandle_t sample_mutex;
static mpu6050_sample_t latest;
static bool started;
static bool last_read_ok;

static esp_err_t register_read(uint8_t reg, uint8_t *data, size_t length)
{
    return i2c_master_transmit_receive(dev_handle, &reg, 1, data, length,
                                        pdMS_TO_TICKS(APP_IMU_I2C_TIMEOUT_MS));
}

static esp_err_t register_write(uint8_t reg, uint8_t value)
{
    uint8_t buffer[2] = {reg, value};
    return i2c_master_transmit(dev_handle, buffer, sizeof(buffer),
                               pdMS_TO_TICKS(APP_IMU_I2C_TIMEOUT_MS));
}

static void sample_task(void *arg)
{
    (void)arg;
    uint8_t raw[14];
    for (;;) {
        esp_err_t err = register_read(MPU6050_REG_ACCEL_XOUT_H, raw, sizeof(raw));
        if (err != ESP_OK) {
            if (last_read_ok) {
                ESP_LOGE(TAG, "MPU-6050 sensor read failed: %s", esp_err_to_name(err));
            }
            last_read_ok = false;
        } else {
            mpu6050_sample_t sample = {
                .ax_g = (int16_t)((raw[0] << 8) | raw[1]) / APP_IMU_ACCEL_SCALE_G,
                .ay_g = (int16_t)((raw[2] << 8) | raw[3]) / APP_IMU_ACCEL_SCALE_G,
                .az_g = (int16_t)((raw[4] << 8) | raw[5]) / APP_IMU_ACCEL_SCALE_G,
                .gx_dps = (int16_t)((raw[8] << 8) | raw[9]) / APP_IMU_GYRO_SCALE_DPS,
                .gy_dps = (int16_t)((raw[10] << 8) | raw[11]) / APP_IMU_GYRO_SCALE_DPS,
                .gz_dps = (int16_t)((raw[12] << 8) | raw[13]) / APP_IMU_GYRO_SCALE_DPS,
                .timestamp_us = esp_timer_get_time(),
                .valid = true,
            };
            if (xSemaphoreTake(sample_mutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                latest = sample;
                xSemaphoreGive(sample_mutex);
            }
            if (!last_read_ok) {
                ESP_LOGI(TAG, "MPU-6050 readings available");
            }
            last_read_ok = true;
        }
        vTaskDelay(pdMS_TO_TICKS(APP_IMU_SAMPLE_PERIOD_MS));
    }
}

bool mpu6050_get_latest(mpu6050_sample_t *sample)
{
    if (sample == NULL || sample_mutex == NULL ||
        xSemaphoreTake(sample_mutex, pdMS_TO_TICKS(5)) != pdTRUE) {
        return false;
    }
    *sample = latest;
    xSemaphoreGive(sample_mutex);
    return sample->valid;
}

bool mpu6050_start(void)
{
    if (started) return true;
    i2c_master_bus_config_t bus_config = {
        .i2c_port = APP_IMU_I2C_PORT,
        .sda_io_num = APP_IMU_SDA_GPIO,
        .scl_io_num = APP_IMU_SCL_GPIO,
        .clk_source = I2C_CLK_SRC_DEFAULT,
        .glitch_ignore_cnt = 7,
        .flags.enable_internal_pullup = false,
    };
    esp_err_t err = i2c_new_master_bus(&bus_config, &bus_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "I2C bus initialization failed: %s", esp_err_to_name(err));
        return false;
    }
    i2c_device_config_t device_config = {
        .dev_addr_length = I2C_ADDR_BIT_LEN_7,
        .device_address = APP_IMU_I2C_ADDRESS,
        .scl_speed_hz = APP_IMU_I2C_FREQ_HZ,
    };
    err = i2c_master_bus_add_device(bus_handle, &device_config, &dev_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "MPU-6050 device registration failed: %s", esp_err_to_name(err));
        return false;
    }
    uint8_t who_am_i = 0;
    err = register_read(MPU6050_REG_WHO_AM_I, &who_am_i, 1);
    if (err != ESP_OK || who_am_i != MPU6050_WHO_AM_I_VALUE) {
        ESP_LOGE(TAG, "MPU-6050 initialization check failed: %s, WHO_AM_I=0x%02X",
                 esp_err_to_name(err), who_am_i);
        return false;
    }
    if ((err = register_write(MPU6050_REG_PWR_MGMT_1, 0x00)) != ESP_OK ||
        (err = register_write(MPU6050_REG_CONFIG, 0x00)) != ESP_OK ||
        (err = register_write(MPU6050_REG_SMPLRT_DIV, 0x09)) != ESP_OK ||
        (err = register_write(MPU6050_REG_GYRO_CONFIG, 0x00)) != ESP_OK ||
        (err = register_write(MPU6050_REG_ACCEL_CONFIG, 0x00)) != ESP_OK) {
        ESP_LOGE(TAG, "MPU-6050 configuration write failed: %s", esp_err_to_name(err));
        return false;
    }
    sample_mutex = xSemaphoreCreateMutex();
    if (sample_mutex == NULL) {
        ESP_LOGE(TAG, "MPU-6050 sample mutex creation failed");
        return false;
    }
    if (xTaskCreate(sample_task, "mpu6050_sample", APP_IMU_TASK_STACK_SIZE, NULL,
                    APP_IMU_TASK_PRIORITY, NULL) != pdPASS) {
        ESP_LOGE(TAG, "Failed to create MPU-6050 sampling task");
        return false;
    }
    started = true;
    last_read_ok = false;
    ESP_LOGI(TAG, "MPU-6050 initialized at 0x%02X on SDA GPIO%d/SCL GPIO%d",
             APP_IMU_I2C_ADDRESS, APP_IMU_SDA_GPIO, APP_IMU_SCL_GPIO);
    return true;
}

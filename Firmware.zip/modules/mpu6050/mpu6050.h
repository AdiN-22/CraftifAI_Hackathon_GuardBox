#ifndef MPU6050_H
#define MPU6050_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    float ax_g;
    float ay_g;
    float az_g;
    float gx_dps;
    float gy_dps;
    float gz_dps;
    int64_t timestamp_us;
    bool valid;
} mpu6050_sample_t;

/** Initialize the MPU-6050 and start periodic sampling. */
bool mpu6050_start(void);

/** Copy the latest sensor sample. Returns false until a valid sample exists. */
bool mpu6050_get_latest(mpu6050_sample_t *sample);

#endif /* MPU6050_H */
